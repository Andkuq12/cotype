require("dotenv").config();

const {
Client,
Intents,
MessageAttachment,
MessageActionRow,
MessageButton
} = require("discord.js");

require("@colors/colors");

const { v4: uuidv4 } = require("uuid");
const tmp = require("tmp");
const axios = require("axios");
const fs = require("fs");
const { spawn } = require("child_process");
const FormData = require("form-data");

const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
const WEBHOOK_URL = process.env.WEBHOOK_URL;

const MAX_SIZE = 40000;

function formatSize(bytes) {
if (bytes < 1024) return bytes + " B";
if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + " KB";
return (bytes / (1024 * 1024)).toFixed(2) + " MB";
}

async function sendWebhook(message, filePath = null) {
if (!WEBHOOK_URL) return;

try {
if (filePath) {
const form = new FormData();
form.append("content", message);
form.append("file", fs.createReadStream(filePath));

await axios.post(WEBHOOK_URL, form, {
headers: form.getHeaders()
});
} else {
await axios.post(WEBHOOK_URL, { content: message });
}
} catch (err) {
console.log("Webhook error:", err.message);
}
}

function obfuscate(input, preset) {
return new Promise((resolve, reject) => {

const output = tmp.fileSync({ postfix: ".lua" });

const proc = spawn("lua", [
"./lua/cli.lua",
"--LuaU",
"--preset",
preset,
input,
"--out",
output.name
]);

proc.stderr.on("data", data => {
sendWebhook("❌ Obfuscation Error:\n" + data.toString());
reject(data.toString());
});

proc.on("close", () => resolve(output));

});
}

console.log("[GRANDFUSCATOR] Starting...".magenta);

const client = new Client({
intents: [
Intents.FLAGS.DIRECT_MESSAGES,
Intents.FLAGS.DIRECT_MESSAGE_REACTIONS
],
partials: ["CHANNEL"]
});

client.login(DISCORD_TOKEN);

client.once("ready", () => {
console.log(`[GRANDFUSCATOR] Logged in as ${client.user.tag}`.green);
});

const buttonMap = new Map();

client.on("interactionCreate", async interaction => {

if (!interaction.isButton()) return;

const data = buttonMap.get(interaction.customId);

if (!data) {
interaction.update({
embeds: [{
title: "Grandfuscator",
description: "Something went wrong.",
color: 0xff0000
}],
components: []
});
return;
}

data.buttonIds.forEach(id => buttonMap.delete(id));

await data.message.edit({
embeds: [{
title: "Grandfuscator",
description: `🔄 Downloading file...
🔄 Obfuscating using ${data.displayPreset}...
🔄 Uploading result...`,
color: 0xff8800
}],
components: []
});

const inputFile = tmp.fileSync({ postfix: ".lua" });

const response = await axios({
method: "GET",
url: data.url,
responseType: "stream"
});

if (
response.headers["content-length"] &&
parseInt(response.headers["content-length"], 10) > MAX_SIZE
) {
await data.message.edit({
embeds: [{
title: "Grandfuscator",
description: "❌ Max file size is 40KB.",
color: 0xff0000
}],
components: []
});
return;
}

response.data.pipe(fs.createWriteStream(inputFile.name));
await new Promise(res => response.data.on("end", res));

await sendWebhook(
`📥 INPUT FILE\nUser: ${data.tag}\nPreset: ${data.displayPreset}`,
inputFile.name
);

let output;

try {
output = await obfuscate(inputFile.name, data.preset);
} catch (e) {
await data.message.edit({
embeds: [{
title: "Grandfuscator",
description: "❌ Obfuscation failed.",
color: 0xff0000
}],
components: []
});
return;
}

await sendWebhook(
`📤 OUTPUT FILE\nUser: ${data.tag}\nPreset: ${data.displayPreset}`,
output.name
);

const attachment = new MessageAttachment(output.name, "obfuscated.lua");

const sent = await data.message.channel.send({
files: [attachment]
});

const fileUrl = sent.attachments.first().url;

const inputSize = fs.statSync(inputFile.name).size;
const outputSize = fs.statSync(output.name).size;
const diff = outputSize - inputSize;

const formattedInput = formatSize(inputSize);
const formattedOutput = formatSize(outputSize);
const formattedDiff = formatSize(Math.abs(diff));

const typeText = data.displayPreset.toLowerCase();

await data.message.edit({
embeds: [{
title: "Grandfuscator",
description:
`**Input**
\`\`\`
${formattedInput}
\`\`\`
**Output**
\`\`\`
${formattedOutput}(+${formattedDiff})
\`\`\`
**Type**
\`\`\`
${typeText}
\`\`\`

✅ Done!

🔗 [Download](${fileUrl})`,
color: 0x00ff00
}],
components: []
});

inputFile.removeCallback();
output.removeCallback();

});

client.on("messageCreate", async message => {

if (message.author.bot) return;

const fileUrl = message.attachments.first()?.url;

if (!fileUrl) {
message.reply("Please upload a .lua file.");
return;
}

const ids = [uuidv4(), uuidv4()];

const row = new MessageActionRow().addComponents(
new MessageButton()
.setCustomId(ids[0])
.setLabel("Normal")
.setStyle("SUCCESS"),

new MessageButton()
.setCustomId(ids[1])
.setLabel("Strong")
.setStyle("PRIMARY")
);

const reply = await message.reply({
embeds: [{
title: "Grandfuscator",
description: "Select preset:",
color: 0xff8800
}],
components: [row]
});

buttonMap.set(ids[0], {
url: fileUrl,
preset: "Weak",
displayPreset: "Normal",
tag: message.author.tag,
message: reply,
buttonIds: ids
});

buttonMap.set(ids[1], {
url: fileUrl,
preset: "Medium",
displayPreset: "Strong",
tag: message.author.tag,
message: reply,
buttonIds: ids
});

});