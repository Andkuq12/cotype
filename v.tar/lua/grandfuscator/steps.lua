return {
	WrapInFunction = require("grandfuscator.steps.WrapInFunction");
	SplitStrings   = require("grandfuscator.steps.SplitStrings");
	Vmify          = require("grandfuscator.steps.Vmify");
	ConstantArray  = require("grandfuscator.steps.ConstantArray");
	ProxifyLocals  = require("grandfuscator.steps.ProxifyLocals");
	AntiTamper  = require("grandfuscator.steps.AntiTamper");
	EncryptStrings = require("grandfuscator.steps.EncryptStrings");
	NumbersToExpressions = require("grandfuscator.steps.NumbersToExpressions");
	AddVararg 	= require("grandfuscator.steps.AddVararg");
}