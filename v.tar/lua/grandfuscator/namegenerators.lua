return {
	Mangled = require("grandfuscator.namegenerators.mangled");
	MangledShuffled = require("grandfuscator.namegenerators.mangled_shuffled");
	Il = require("grandfuscator.namegenerators.Il");
	Number = require("grandfuscator.namegenerators.number");
	Confuse = require("grandfuscator.namegenerators.confuse");
}