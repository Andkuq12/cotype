import axios from "axios";
import FormData from "form-data";
import fs from "fs";

const WEBHOOK_URL = process.env.WEBHOOK_URL as string;

async function sendWebhook(content: string) {
    if (!WEBHOOK_URL) return;

    try {
        await axios.post(WEBHOOK_URL, {
            content
        });
    } catch (err) {
        console.error("Webhook error:", err);
    }
}

async function sendFile(filePath: string) {
    if (!WEBHOOK_URL) return;

    const form = new FormData();
    form.append("file", fs.createReadStream(filePath));

    try {
        await axios.post(WEBHOOK_URL, form, {
            headers: form.getHeaders()
        });
    } catch (err) {
        console.error("Webhook file error:", err);
    }
}

export default {
    log: (...message: unknown[]) => {
        const msg = `[GRANDFUSCATOR] ${message.join(" ")}`;
        console.log(msg);
        sendWebhook("🟢 " + msg);
    },
    warn: (...message: unknown[]) => {
        const msg = `[GRANDFUSCATOR] ${message.join(" ")}`;
        console.warn(msg);
        sendWebhook("🟡 " + msg);
    },
    error: (...message: unknown[]) => {
        const msg = `[GRANDFUSCATOR] ${message.join(" ")}`;
        console.error(msg);
        sendWebhook("🔴 " + msg);
    },
    sendFile
};