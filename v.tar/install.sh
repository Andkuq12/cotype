#!/bin/bash
set -e

INSTALL_DIR="$HOME/.local"
mkdir -p $INSTALL_DIR

echo "=== Install TypeScript globally (via npm) ==="
npm install -g typescript
tsc -v

echo "=== Install Lua 5.4 (compile manual, tanpa root) ==="
cd $HOME
curl -R -O https://www.lua.org/ftp/lua-5.4.6.tar.gz
tar zxf lua-5.4.6.tar.gz
cd lua-5.4.6
make linux MYCFLAGS="-fPIC"
make install INSTALL_TOP=$INSTALL_DIR/lua

echo 'export PATH=$HOME/.local/lua/bin:$PATH' >> $HOME/.bashrc
export PATH=$HOME/.local/lua/bin:$PATH

lua -v

echo "=== SELESAI ==="
echo "Jalankan: source ~/.bashrc"